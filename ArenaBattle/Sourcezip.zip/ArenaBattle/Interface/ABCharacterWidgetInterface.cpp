// Fill out your copyright notice in the Description page of Project Settings.


#include "Interface/ABCharacterWidgetInterface.h"

// Add default functionality here for any IABCharacterWidgetInterface functions that are not pure virtual.
