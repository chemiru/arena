
#pragma once

#include "CoreMinimal.h"

# define CPROFILE_ABCAPSULE TEXT("ABCapsule")
# define CPROFILE_ABTRIGGER TEXT("ABTrigger")
# define CCHANNEL_ABACTION ECC_GameTraceChannel1

